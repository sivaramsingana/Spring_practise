package webgroup.webartifact;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloWorldController {

	@RequestMapping("/helloworld")
	public String getHelloWorld(Model model) {
		Map m= new HashMap();
		m.put("message1","Welcome to world");
		
		model.addAttribute("message","helloWorld");
		model.addAttribute(m);
		
		return "view";
	}
	
	@RequestMapping("/helloworld1")
	public String getHelloWorld1(ModelMap model) {
		
		model.addAttribute("message","helloWorld");
		model.addAttribute("message1","Some message receive");
		
		
		
		
		return "view";
	}

	
	@RequestMapping("/getnames")
	public ModelAndView getNames(ModelAndView model) {
		
		List<String> Names= Arrays.asList("bob","ram");
		
		model.setViewName("view");
		model.addObject("names",Names);
		
		
		return model;
	}

}
