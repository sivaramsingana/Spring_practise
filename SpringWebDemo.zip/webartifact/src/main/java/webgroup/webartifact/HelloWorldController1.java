package webgroup.webartifact;

import java.util.Arrays;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloWorldController1 {

	
	@RequestMapping("/Welcome")
	@ResponseBody
	
	public String sampleTest()
	{
		return "Welcome to Spring restful web services";
	}
	
	@RequestMapping("/Welcome1")
	public ResponseEntity<String> sampleTest1()
	{
		return new ResponseEntity<String>("Welcome to HTTP Test case",HttpStatus.OK);
	}
	
	
	
	public static List<List<String>> students=Arrays.asList(
			Arrays.asList("mani","joe","tim"),
			Arrays.asList("sita","rama","lakshman"),
			Arrays.asList("ram","Shyam","prem"));
	
	@RequestMapping(value="/getStudents/{classID}",method=RequestMethod.GET)
	@ResponseBody
	public String getStudents(@PathVariable Integer classID)
	{
		return students.get(classID-1).toString();
		
	}
	
	
	@RequestMapping(value="/getStudent",method=RequestMethod.POST)
	@ResponseBody
	public String getStudents1(@RequestParam Integer classID)
	{
		return students.get(classID-1).toString();
		
	}
}
