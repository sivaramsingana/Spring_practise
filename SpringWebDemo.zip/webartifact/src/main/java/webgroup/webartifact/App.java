package webgroup.webartifact;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

/**
 * Hello world!
 *
 */

@Controller
public class App 
{
/*	you have to change dispatcher servlet to make html work since we changed view resolver
 * 	@RequestMapping("/hello")
    public static String helloWorld( String[] args )
    {
        System.out.println( "Hello World!" );
        return "WEB-INF/helloworld.html";
    }
*/	
	@RequestMapping("/getmodel")
	public static ModelAndView getpoint(ModelAndView mv) {
		
		Point p = new Point();
		
		p.setX(10.2);
		p.setY(20.4);
		
		
		mv.addObject("PointX",p.getX());
		mv.addObject("PointY",p.getY());
		mv.setViewName("helloworld");
		return mv;
		
		
	}
}
